function conc()
{
	var name = "Amit";
	var surname = "Parmar";
	var display = "Name: " + name + "<br/>" + "Surname: " + surname;
	display += "<br/>" + "Full Name: " + name + " " + surname;
	document.getElementById("jsExample").innerHTML = display;
}

function strLen()
{
	let paraLen = document.getElementById("jsExample").innerHTML.length;
	document.getElementById("jsExampleTwo").innerHTML = paraLen;
}

function reset()
{
	let orgVal = "JavaScript output will be displayed here."
	document.getElementById("jsExample").innerHTML = orgVal;
	document.getElementById("jsExampleTwo").innerHTML = null;	
}

function search()
{
	var word = document.getElementById("wordSearch").value;
	document.getElementById("wordList").innerHTML += "<li>" + word + "</li>";
	document.getElementById("wordSearch").value = "";
}

function loadJs()
{
	var numOne = 10;
	var numTwo = 2;
	var result = numOne + numTwo;
	document.getElementById("sum").innerHTML = "Sum of " + numOne + " and " + numTwo + " = " + result;
	result = numOne - numTwo;
	document.getElementById("subtract").innerHTML = numOne + " minus " + numTwo + " = " + result;
	result = numOne * numTwo;
	document.getElementById("multiply").innerHTML = "Multiplcation of " + numOne + " and " + numTwo + " = " + result;
	result = numOne / numTwo;
	document.getElementById("division").innerHTML = numOne + " divided by " + numTwo + " = " + result;	


	var arrayN = ["Toyota","Honda","Subaru","Mitsubishi"];
	document.getElementById("arrPara").innerHTML = 	arrayN + "</br>" + arrayN.join("</br	>");

}